# SurfRideTools
This is a python package for converting compiled surfride library files.<br>
<br>
Current features:<br>
- surfride2json: convert an `.sbscene` file to `json`.<br>
